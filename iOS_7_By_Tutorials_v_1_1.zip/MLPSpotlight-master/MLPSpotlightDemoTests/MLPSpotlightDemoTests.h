//
//  MLPSpotlightDemoTests.h
//  MLPSpotlightDemoTests
//
//  Created by Eddy Borja on 1/26/13.
//  Copyright (c) 2013 Mainloop. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MLPSpotlightDemoTests : SenTestCase

@end
